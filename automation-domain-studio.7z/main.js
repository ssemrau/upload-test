const { app, BrowserWindow, Menu } = require('electron')
const { runTest } = require('./browser-controller');

var browser = null;

var openPage = (url) => {
    browser = runTest(url);
}

function createWindow () {
  const win = new BrowserWindow({
    webPreferences: {
      nodeIntegration: true
    }
  })

  win.maximize();
  win.loadFile('index.html');
  //win.webContents.openDevTools();

}

try {
    app.whenReady().then(createWindow)
} catch {}


app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }

  if (browser) {
    browser.close();
  }  
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})