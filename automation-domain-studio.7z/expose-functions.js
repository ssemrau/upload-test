const logFunction = (text) => {
    var selector = `Selector('${text}')`;
    document.getElementById('jsModel').value += selector + '\r\n';
}

exports.logFunction = logFunction;