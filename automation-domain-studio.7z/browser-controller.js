const puppeteer = require('puppeteer');

const { logFunction } = require('./expose-functions');

const runTest = async (url) => {
  document.getElementById('jsModel').value = '';
  const browser = await puppeteer.launch({
    args: [
        '--no-sandbox',
        '--start-maximized'
    ],
    browser: 'chrome',
    headless: false,
    defaultViewport: null
  });
  
  const pages = await browser.pages();  
  let page = null;
  if (pages.length > 0) {
    page = pages[0];
  } else {
    page = await browser.newPage();
  }

  await page.exposeFunction('logFunction', text => logFunction(text))
  
  await page.evaluateOnNewDocument(() => { 
    const handleDocumentLoaded = () => {
      
        var getClass = function (element) {
            var classList = '';
            if (element.classList) {
                for (var i = 0; i < element.classList.length ; i++) {
                    classList += '.' + element.classList[i];
                }
            }
            return classList;
        }

        var getPath = function (event) {
            var path = '';   

            if (event.target.id) {
                return '#' + event.target.id;
            }

            for(var i = 0; i < event.path.length; i++) {
                if(event.path[i].localName) {
                    path = event.path[i].localName + getClass(event.path[i]) + ' ' + path;
                    if (document.querySelectorAll(path).length === 1) {
                        return path.trim();
                    }                    
                }
            }

            return path.trim();
        }

        document.addEventListener('focus',function (event) {
            var path = getPath(event);
            window.logFunction(path);
            // console.log('focus', event.target);
        }, true);

        document.onclick = function (event) {    
          
          event.target.onblur = function (event) {
              var path = getPath(event);
              console.log('blur', path);
          }
          
          //var path = getPath(event);
          //window.logFunction(path);
          console.log(event);
        }

    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", handleDocumentLoaded);
    } else {
      handleDocumentLoaded();
    }
  });
  
  await page.goto(url);  

  return browser;
};

exports.runTest = runTest;