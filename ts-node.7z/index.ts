import { FixtureBase } from './lib/fixture-base';
import { CommonDefualtProps, MotorDefualtProps } from './lib/default-props';

class PCITC0001 extends FixtureBase {    
    constructor () {
        super();        
        this.builder
            .addMetatags(m => {
                m.container = 'PCI';
                m.testCaseId = 'TC0001';
                return m;
            })    
            .addFixture(f => {
                f.name = 'Axa NB FrontOffice and MTA FrontOffice';
                f.brand = 'Axa';
                f.product = 'Motor';
                return f;
            })
            .addTest('quote', 'motor-quote', 'FrontOffice', t => {
                t.addDefaults(MotorDefualtProps.getInstance())
                t.addDefaults(CommonDefualtProps.getInstance())
                t.addPage('yourdetaislPage', p => {
                    p.policyholderFirstname = 'NB FO';
                    p.policyholderSurname = 'Single Initial';
                    p.todayDate = 'getDate()'            
                    return p;
                });            
                t.addPage('quotePage', p => p)
                t.addPage('summaryPage', p => p)
                t.addPage('paymentPage', p => {
                    p.cardholderName = 'NB FO Single Initial';
                    return p;
                })
                t.addPage('threedsPage', p => {
                    p.inputValue = 'challenge';
                    return p;
                })
                t.addPage('registrationPage', p => p)

                return t;
            });
    }    
}

class PCITC0002 extends PCITC0001 {
    constructor () {
        super();
        this.builder
            .addMetatags(m => {                                
                m.container = 'PCI';
                m.testCaseId = 'TC0002';
                return m;
            })    
            .addFixture(f => {
                f.name = 'Swiftcover NB FrontOffice and MTA FrontOffice';
                f.brand = 'Swiftcover';
                f.product = 'Motor';
                return f;
            });
    }
}

class PCITC0003 extends PCITC0001 {
    constructor () {
        super();
        this.builder
            .addMetatags(m => {                                
                m.container = 'PCI';
                m.testCaseId = 'TC0003';
                return m;
            })    
            .addFixture(f => {
                f.name = 'Swiftcover NB FrontOffice and MTA FrontOffice';
                f.brand = 'Swiftcover';
                f.product = 'Motor';
                return f;
            });
        var page = this.builder.tests.find(t => t.name === 'quote')?.context['yourdetaislPage'];
        if(page) {            
            page.RegistrationNumber = 'LV06KPJ';            
        }        
    }
}

console.log(new PCITC0001().toString());

console.log(new PCITC0002().toString());

console.log(new PCITC0003().toString());