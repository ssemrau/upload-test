import CommonDefualtProps from './common-default-props';
import MotorDefualtProps from './motor-default-props';

export { CommonDefualtProps, MotorDefualtProps }