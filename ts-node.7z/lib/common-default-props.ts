import LooseObject from './loose-object'

export default class CommonDefualtProps extends LooseObject<string> {
    private static instance: CommonDefualtProps;

    private constructor () {
        super();
        this.Email = 'getEmail()';
        this.StartDate = 'getDate()';
        this.FirstName = 'First';
        this.LastName = 'Last';
    }    

    public static getInstance = (): CommonDefualtProps => {
        if(!CommonDefualtProps.instance) {
            CommonDefualtProps.instance = new CommonDefualtProps();
        }

        return CommonDefualtProps.instance;
    }
}