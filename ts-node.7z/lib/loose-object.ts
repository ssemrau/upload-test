export default class LooseObject<T> {
    [key: string]: T;
}