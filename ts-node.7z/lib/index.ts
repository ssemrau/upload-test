import LooseObject from './loose-object'

class RootBuilder {
    metatags?: Metatags;
    fixture?: Fixture;
    tests: Test[] = [];

    stringify = (): string => {

        return `{
    "metatags": ${JSON.stringify(this.metatags, this.replacer)},
    "fixture": ${JSON.stringify(this.fixture, this.replacer)},
    "tests": ${JSON.stringify(this.tests, this.replacer)}
}`;        
    }

    private replacer = (key: string, value: any): any => {
        if(key === '__defaults__') {
            return undefined;
        }

        return value;
    }

    private mergeTags = () => {   
        this.mergeTag(this.fixture?.brand);
        this.mergeTag(this.fixture?.product);
    }

    private mergeTag = (tag?: string) => {
        if(tag && !this.metatags?.tags.find(t => t === tag)) {
            this.metatags?.tags.push(tag);        
        }
    }

    addMetatags = (tagsBuilder: (m: Metatags) => Metatags) => {
        this.metatags = tagsBuilder(new Metatags())
        // this.mergeTags();
        return this;
    }    

    addFixture = (fixtureBuilder: (f: Fixture) => Fixture) => {
        this.fixture = fixtureBuilder(new Fixture());
        this.mergeTags();
        return this;
    }    

    addTest = (name: string, file: string, channel: string, testBuilder: (t: Test) => Test) => {
        const test = testBuilder(new Test(name, file, channel));     
        if(this.tests.find(t => t.name === name)) {
            throw new Error(`Test ${name} already exists.`);
        }   
        this.tests.push(test);
        return this;
    }    
}

class Test {
    file?: string;
    channel?: string;    
    name?: string;
    context: LooseObject<Page> = {};

    private __defaults__: LooseObject<string> = {};
    
    constructor(name: string, file: string, channel: string) {
        this.name = name;
        this.file = file;
        this.channel = channel;
        
    }        

    private propagateDefaultsToPage = (page: Page) => {
        if(this.__defaults__) {
            const keys = Object.keys(this.__defaults__);        
            keys.forEach(key => {
                if(!page[key]) {
                    page[key] = this.__defaults__[key];
                }
            })
        }
    }

    private propagateDefaultsToPages = () => {        
        const pages = Object.keys(this.context);
        pages.forEach(page => {
            this.propagateDefaultsToPage(this.context[page]);
        })                                 
    }

    addPage = (name: string, pageBulder: (p: Page) => Page) => {
        const page = pageBulder(new Page())
        if(this.context[name]) {
            // do nothing and return as page was inherited from other test
            return this;
            // throw new Error(`Page ${name} already exists`);
        }
        this.context[name] = page;
        this.propagateDefaultsToPage(page);
        return this;
    }

    addDefaults = (defaults: LooseObject<string>) => {
        if(defaults) {
            const keys = Object.keys(defaults);
            keys.forEach(key => {                                
                this.__defaults__[key] = defaults[key];
            })
        }

        this.propagateDefaultsToPages();
        return this;
    }    
}

class Page extends LooseObject<any> {
    assertions?: Assertion[];
    addAssertion = (name: string, assertionBuilder: (a: Assertion) => Assertion) => {
        const assertion = assertionBuilder(new Assertion(name))
        if(!this.assertions) {
            this.assertions = [];
        }
        this.assertions.push(assertion);
    }
}

class Assertion extends LooseObject<any> {
    name?: string;
    expected?: Expected

    constructor(name: string) {
        super();
        this.name = name;
    }

    expectedValue = (value: string) => {
        this.expected = new Expected();
        this.expected.value = value;
        return this;
    }

    expectedProperty = (property: string) => {
        this.expected = new Expected();
        this.expected.property = property;
        return this;
    }
}

class Expected {
    property?: string;
    value?: string
}

class Metatags {    
    tags: string[] = [];
    container?: string;
    testCaseId? :string;        

    addTag = (tag: string) => {
        if(this.tags.find(t => t === tag)) {
            throw new Error(`Tag ${tag} is already added`);
        }
        this.tags.push(tag)
        return this;
    }
}

class Fixture {    
    name?: string;
    product?: string;
    brand?: string;
}

export { RootBuilder }