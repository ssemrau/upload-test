import { RootBuilder } from './index';

class FixtureBase {
    builder: RootBuilder;

    constructor () {
        this.builder = new RootBuilder();
    }

    toString = (): string => {
        return this.builder.stringify();
    }
}

export { FixtureBase }